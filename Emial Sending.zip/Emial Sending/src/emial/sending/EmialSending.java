/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package emial.sending;
import java.awt.HeadlessException;
import java.io.File;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;
/**
 *
 * @author akvnr
 */
public class EmialSending {
    public static void main(String[] args) {
        //1. FIRST DOWNLOAD JAVAX.MAIL JAR
//ADD TO PROJECT LIBRARY
//2. AND USE THE CODE
String  to = ""; // to address. It can be any like gmail, hotmail etc.
String   from = ""; // from address. As this is using Gmail SMTP.
String  password = ""; // password for from mail address. 
String sub="Your Purchase Is Successfull";
String      content="";
 
  Properties prop = new Properties();
  prop.put("mail.smtp.host", "smtp.gmail.com");
  prop.put("mail.smtp.port", "465");
  prop.put("mail.smtp.auth", "true");
  prop.put("mail.smtp.socketFactory.port", "465");
  prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
 
  Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
   @Override
   protected PasswordAuthentication getPasswordAuthentication() {
    return new PasswordAuthentication(from, password);
   }
  });
 
  try{
            MimeMessage m =new MimeMessage(session);
            m.setFrom(from);
            m.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            m.setSubject(sub);
            m.setText(content);
            MimeBodyPart mimeBodyPart = new MimeBodyPart();
            mimeBodyPart.setContent(content, "text/html");
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(mimeBodyPart);
    
   MimeBodyPart attachmentBodyPart = new MimeBodyPart();
     try {
         attachmentBodyPart.attachFile(new File(""));
     } catch (IOException ex) {
         
     }
             multipart.addBodyPart(attachmentBodyPart);
            m.setContent(multipart);
            Transport.send(m);
            JOptionPane.showMessageDialog(null, "Successfully");
            
            
        }
        catch(HeadlessException | MessagingException e)
        {
            JOptionPane.showMessageDialog(null, "unsuccessfull");
        }
		
		
 //3. In The Line 38 , Change Attachment Name ,According to Ur Convinience
    }
    
}
